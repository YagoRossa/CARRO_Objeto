package controle;

import java.util.ArrayList;
import java.util.Scanner;
import modelo.Carro; // Importar a classe Carro

public class CarroControle {

    private ArrayList<Carro> listaCarros = new ArrayList<>();

    public ArrayList<Carro> getListaCarros() {
        return listaCarros;
    }

    public void setListaCarros(ArrayList<Carro> listaCarros) {
        this.listaCarros = listaCarros;
    }

    public void cadastrarCarro() {
        System.out.println("...:::  Cadastrar Carro :::...");
        System.out.println("--------------------------------");

        Carro carro = new Carro();
        carro.lerCarro();
        listaCarros.add(carro);

        System.out.println("----------------------------");
    }

    public void listarCarros() {
        System.out.println("...:::  Listar Carros :::...");
        System.out.println("----------------------------");

        for (Carro carro : listaCarros) {
            carro.listarCarro();
        }

        System.out.println("----------------------------");
    }

    public void visualizarCarro() {
        System.out.println("...:::  Visualizar Carro :::...");
        System.out.println("----------------------------");

        for (Carro carro : listaCarros) {
            carro.visualizarCarro();
        }

        System.out.println("----------------------------");
    }

    public void editarCarro() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("...:::  Editar Carro :::...");
        System.out.println("----------------------------");

        System.out.print("Digite o modelo do carro a ser editado: ");
        String modeloEditar = scanner.next();
        boolean encontrado = false;

        for (Carro carro : listaCarros) {
            if (carro.getModelo().equals(modeloEditar)) {
                carro.lerCarro();
                System.out.println("Carro editado com sucesso!");
                encontrado = true;
                break; // Se encontrado, não é necessário continuar a busca
            }
        }

        if (!encontrado) {
            System.out.println("Carro não encontrado.");
        }

        System.out.println("----------------------------");
    }

     public void removerCarro() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("...:::  Remover Carro :::...");
        System.out.println("----------------------------");

        System.out.print("Digite o modelo do carro a ser removido: ");
        String modeloRemover = scanner.next();
        boolean encontrado = false;

        for (Carro carro : listaCarros) {
            if (carro.getModelo().equals(modeloRemover)) {
                listaCarros.remove(carro);
                System.out.println("Carro removido com sucesso!");
                encontrado = true;
                break; // Se encontrado, não é necessário continuar a busca
            }
        }

        if (!encontrado) {
            System.out.println("Carro não encontrado.");
        }

        System.out.println("----------------------------");
    }

     public void pesquisarCarro() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("...:::  Pesquisar Carro :::...");
        System.out.println("----------------------------");

        System.out.print("Digite o modelo do carro a ser pesquisado: ");
        String modeloPesquisar = scanner.next();
        boolean encontrado = false;

        for (Carro carro : listaCarros) {
            if (carro.getModelo().equals(modeloPesquisar)) {
                carro.visualizarCarro();
                encontrado = true;
                break; // Se encontrado, não é necessário continuar a busca
            }
        }

        if (!encontrado) {
            System.out.println("Carro não encontrado.");
        }

        System.out.println("----------------------------");
    }
}