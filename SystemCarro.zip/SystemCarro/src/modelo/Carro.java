package modelo;

import java.util.Scanner;

public class Carro {

    private String modelo;
    private String marca;
    private int anoFabricacao;
    private String cor;
    private double quilometragem;

    public Carro(String modelo, String marca, int anoFabricacao, String cor, double quilometragem) {
        this.modelo = modelo;
        this.marca = marca;
        this.anoFabricacao = anoFabricacao;
        this.cor = cor;
        this.quilometragem = quilometragem;
    }

    public Carro() {
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getAnoFabricacao() {
        return anoFabricacao;
    }

    public void setAnoFabricacao(int anoFabricacao) {
        this.anoFabricacao = anoFabricacao;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public double getQuilometragem() {
        return quilometragem;
    }

    public void setQuilometragem(double quilometragem) {
        this.quilometragem = quilometragem;
    }

    @Override
    public String toString() {
        return "Carro{" + "modelo=" + modelo + ", marca=" + marca + ", anoFabricacao=" + anoFabricacao + ", cor=" + cor + ", quilometragem=" + quilometragem + '}';
    }

    public void lerCarro() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Modelo: ");
        this.setModelo(scanner.next());

        System.out.print("Marca: ");
        this.setMarca(scanner.next());

        System.out.print("Ano de Fabricação: ");
        this.setAnoFabricacao(scanner.nextInt());

        System.out.print("Cor: ");
        this.setCor(scanner.next());

        System.out.print("Quilometragem: ");
        this.setQuilometragem(scanner.nextDouble());
    }

    public void visualizarCarro() {
        System.out.println("Modelo: " + this.getModelo());
        System.out.println("Marca: " + this.getMarca());
        System.out.println("Ano de Fabricação: " + this.getAnoFabricacao());
        System.out.println("Cor: " + this.getCor());
        System.out.println("Quilometragem: " + this.getQuilometragem());

        System.out.println();
    }

    public void listarCarro() {
        System.out.println("Modelo: " + this.getModelo());
        System.out.println("Marca: " + this.getMarca());
        System.out.println("Ano de Fabricação: " + this.getAnoFabricacao());

        System.out.println();
    }
}