package visao;

import controle.CarroControle; // Alterar o import para a classe CarroControle
import java.util.Scanner;

public class SystemCarro {

    public static void main(String[] args) {
        int op;

        CarroControle controleCarro = new CarroControle();

        while (true) {

            op = imprimirMenu();

            if (op == 0) {
                System.out.println("Saindo do programa de carros! Até mais...");
                break;
            }

            switch (op) {
                case 1:
                    controleCarro.cadastrarCarro();
                    break;

                case 2:
                    controleCarro.editarCarro();
                    break;

                case 3:
                    controleCarro.removerCarro();
                    break;

                case 4:
                    controleCarro.listarCarros();
                    break;

                case 5:
                    controleCarro.visualizarCarro();
                    break;

                case 6:
                    controleCarro.pesquisarCarro();
                    break;
            }
        }
    }

    public static int imprimirMenu() {
        int op = -1;

        Scanner scanner = new Scanner(System.in);

        System.out.println("...:::  Menu - Carros :::...");
        System.out.println(""
                + "\t1) Cadastrar\n"
                + "\t2) Editar\n"
                + "\t3) Remover\n"
                + "\t4) Listar\n"
                + "\t5) Visualizar\n"
                + "\t6) Pesquisar\n"
                + "\t0) Sair");
        System.out.print("Opção-> ");

        op = scanner.nextInt();

        return op;
    }
}